README FILE:
Instructions:
1. Keep all the files in the same folder
2. Start a jupiter notebook server in the folder
3. ENSURE THAT SKLEARN LIBRARIES and JUPYTER NOTEBOOK LIBRARIES are completely installed, code won't run without this
4. Run the notebooks there is one notebook for each dataset, DO NOT RUN THE GRIDSEARCH PARTS, most of these take forever to run, especially with the Dota2 dataset.


Acknowledgements:
- SKLearn libraries and documentations
- https://stackoverflow.com/questions/39002230/possible-to-modify-prune-learned-trees-in-scikit-learn

Dataset sources:
- https://archive.ics.uci.edu/ml/datasets/Dota2+Games+Results
- https://www.kaggle.com/c/poker-rule-induction
