README FILE:
Instructions:
1. Keep all the files in the same folder
2. This is an Intellij project, please open the folder with Intellij, otherwise please setup so that the project
is run with the provided ABAGAIL.jar, otherwise code will not run.
3. Run the mains of each of the files to see output. Note that for Poker2, there is an algorithm tuning zone that is
commented out.

Acknowledgements:
- https://github.com/pushkar/ABAGAIL
- https://gist.github.com/mosdragon/53edf8e69fde531db69e

Dataset sources:
- https://archive.ics.uci.edu/ml/datasets/Dota2+Games+Results