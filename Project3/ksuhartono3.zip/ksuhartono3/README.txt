README FILE:
Instructions:
1. Keep all the files in the same folder
2. Start a jupyter notebook server in the folder
3. ENSURE THAT SKLEARN LIBRARIES and JUPYTER NOTEBOOK LIBRARIES are completely installed, code won't run without this
4. Run the notebooks there is one notebook for each dataset, some of them need to be run sequentially (Part 5 of the assignment)

Acknowledgements:
- SKLearn libraries and documentations

Dataset sources:
- https://archive.ics.uci.edu/ml/datasets/Dota2+Games+Results
- https://www.kaggle.com/c/poker-rule-induction
