README FILE:
Instructions:
1. Keep all the files in the same folder
2. All the code is in Project4_2 folder
3. Install the required dependency for the project to run:
	- BURLAP: http://burlap.cs.brown.edu/tutorials/hgw/p1.html
4. This is an IntelliJ project, opening it with IntelliJ should allow you to run the code provided all the dependencies are installed. This project needs BURLAP installed which will have its own dependencies, simply follow the instructions from the link above to install burlap and ensuring it runs properly
5. Run the mains of each of the files to see output. Can simply run the mains of either one of the grid worlds. Modify from policyIteration to valueIteration or vice versa in the main to switch between the training algorithms.

Acknowledgements:
- http://burlap.cs.brown.edu/index.html